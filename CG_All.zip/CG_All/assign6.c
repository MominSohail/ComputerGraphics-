
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>

const int INSIDE = 0; // 0000
const int LEFT = 1;   // 0001
const int RIGHT = 2;  // 0010
const int BOTTOM = 4; // 0100
const int TOP = 8;    // 1000

//prototype declaration
int take_Poly(int a[10][2]);
void disp_Poly(int a[10][2],int n);
int ComputeOutCode(double x, double y, double xmin, double ymin, double xmax, double ymax);
void coh_suth(double x0, double y0, double x1, double y1, double xmin, double ymin, double xmax, double ymax);
void suth_hodg(int p[10][2], int n, int xmin, int xmax, int ymin, int ymax);

int main()
{
	int gd=DETECT,gm;
	int ch, xl, xh, yl, yh, x1, y1, x2, y2, a[10][2], n;
	printf("Enter\n1.Line clipping\n2.Polygon clipping\n");
	scanf("%d", &ch);
	switch(ch)
	{
		case 1:
			printf("Enter co-ordinates of rectangular clipping window\n");
                        printf("\n(Xmin ,Ymin) :"); 
			scanf("%d%d", &xl, &yl);
                        printf("\n(Xmax ,Ymax) :");
                        scanf("%d%d", &xh, &yh);
			printf("Enter co-ordinates of line to be clipped\n");
                        printf("\n(X1,Y1): ");
                        scanf("%d%d", &x1, &y1);
                        printf("\n(X2,Y2): ");
			scanf("%d%d", &x2, &y2);
			initgraph(&gd,&gm,"");
                        line(0,240,640,240);
			line(320,0,320,480);
                        outtextxy(150,20,"BEFOR Line Clipping");
                        rectangle(320+round(xl), 240-round(yl), 320+round(xh), 240-round(yh));
                        line(320+x1, 240-y1, 320+x2, 240-y2);
			delay(2000);
                        
                        cleardevice();
                        line(0,240,640,240);
			line(320,0,320,480);
			coh_suth(x1, y1, x2, y2, xl, yl, xh, yh);
			getch();	
			closegraph();		
			break;
		case 2:
			printf("Enter co-ordinates of rectangular clipping window\n");
                        printf("\n(Xmin ,Ymin)"); 
			scanf("%d%d", &xl, &yl);
                        printf("\n(Xmax ,Ymax)");
                        scanf("%d%d", &xh, &yh);
			n=take_Poly(a);
			initgraph(&gd,&gm,"");
                        line(0,240,640,240);
			line(320,0,320,480);
                        outtextxy(150,20,"BEFOR Polygon Clipping");
                        rectangle(320+round(xl), 240-round(yl), 320+round(xh), 240-round(yh));
                        disp_Poly(a,n);
                        delay(2000);                        

                        cleardevice();

                        line(0,240,640,240);
			line(320,0,320,480);    
			suth_hodg(a, n, xl, xh, yl, yh);
			getch();	
			closegraph();
			break;
		case 3:
		exit(0);
	}
	return 0;
}

int take_Poly(int a[10][2])
{
	int i,n;
	printf("Enter number of edges of polygon: ");
	scanf("%d",&n);
	printf("Enter vertices of polygon in order\n");
	for(i=0;i<n;i++)
	{
                printf("\n(X%d,Y%d) :",i+1,i+1);
		scanf("%d%d",&a[i][0],&a[i][1]);
	}
	return n;
}

void disp_Poly(int a[10][2],int n)
{
	int i;
	for(i=0;i<n-1;i++)
	{
		line(320+a[i][0],240-a[i][1],320+a[i+1][0],240-a[i+1][1]);
	}
	line(320+a[n-1][0],240-a[n-1][1],320+a[0][0],240-a[0][1]);
}


int ComputeOutCode(double x, double y, double xmin, double ymin, double xmax, double ymax)
{
	int code;

	code = 0;
	if (x < xmin)
		code |= 1;
	else if (x > xmax)
		code |= 2;
	if (y < ymin)
		code |= 4;
	else if (y > ymax)
		code |= 8;

	return code;
}

void coh_suth(double x0, double y0, double x1, double y1, double xmin, double ymin, double xmax, double ymax)
{
	int outcode0 = ComputeOutCode(x0, y0, xmin, ymin, xmax, ymax);
	int outcode1 = ComputeOutCode(x1, y1, xmin, ymin, xmax, ymax);
	int accept=0;
	rectangle(320+round(xmin), 240-round(ymin), 320+round(xmax), 240-round(ymax));
	circle(320+round(x0), 240-round(y0), 2);
	circle(320+round(x1), 240-round(y1), 2);
	while (1)
	{
		if (!(outcode0 | outcode1))
		{
			accept = 1;
			break;
		} 
		else if (outcode0 & outcode1) 
		{ 			
			break;
		}
		else
		{
			double x, y;
			int outcodeOut = outcode0 ? outcode0 : outcode1;

			if (outcodeOut & 8)
			{// point is above the clip rectangle
				x = x0 + (x1 - x0) * (ymax - y0) / (y1 - y0);
				y = ymax;
			}
			else if (outcodeOut & BOTTOM)
			{ // point is below the clip rectangle
				x = x0 + (x1 - x0) * (ymin - y0) / (y1 - y0);
				y = ymin;
			}
			else if (outcodeOut & RIGHT)
			{  // point is to the right of clip rectangle
				y = y0 + (y1 - y0) * (xmax - x0) / (x1 - x0);
				x = xmax;
			}
			else if (outcodeOut & LEFT)
			{   // point is to the left of clip rectangle
				y = y0 + (y1 - y0) * (xmin - x0) / (x1 - x0);
				x = xmin;
			}

			// Now we move outside point to intersection point to clip
			// and get ready for next pass.
			if (outcodeOut == outcode0)
			{
				x0 = x;
				y0 = y;
				outcode0 = ComputeOutCode(x0, y0, xmin, ymin, xmax, ymax);
			}
			else
			{
				x1 = x;
				y1 = y;
				outcode1 = ComputeOutCode(x1, y1, xmin, ymin, xmax, ymax);
			}
		}
	}
	if(accept)
              {

		line(320+x0, 240-y0, 320+x1, 240-y1);
           outtextxy(150,20,"AFTER Clipping");
                  }
}

void suth_hodg(int p[10][2], int n, int xmin, int xmax, int ymin, int ymax)
{
	int i;
	line(0,240,640,240);
	line(320,0,320,480);
	for(i=0;i<n-1;i++)
		coh_suth(p[i][0],p[i][1],p[i+1][0],p[i+1][1],xmin,ymin,xmax,ymax);
	coh_suth(p[0][0],p[0][1],p[n-1][0],p[n-1][1],xmin,ymin,xmax,ymax);
	getch();	
	closegraph();
}


