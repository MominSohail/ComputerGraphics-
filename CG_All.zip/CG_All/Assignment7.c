/*
 * curve.c
 *
 *  Created on: 31-Mar-2015
 *      Flower using bezier curve
 
 
 */

#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>

void bezier(int x[4],int y[4])
{
	int gd = DETECT,gm,i;
	double xt,yt,t;
	int midx,midy;
	initgraph(&gd,&gm,"...\\bgi");
	midx = getmaxx()/2;
	midy = getmaxy()/2;
	for(t = 0.0;t < 1.0;t += 0.0005)
	{
		xt = pow(1-t,3)*x[0] + 3*t*pow(1-t,2)*x[1] + 3*(1-t)*pow(t,2)*x[2] + pow(t,3)*x[3];
		yt = pow(1-t,3)*y[0] + 3*t*pow(1-t,2)*y[1] + 3*(1-t)*pow(t,2)*y[2] + pow(t,3)*y[3];
		putpixel(xt+midx,midy-yt,WHITE);
	}
	for(i = 0;i < 4;i++)
		putpixel(midx+x[i],midy-y[i],YELLOW);
	delay(7000);
	closegraph();
}

void bezier_pattern(int x[4],int y[4])
{
	int gd = DETECT,gm,i;
	double xt,yt,t;
	int midx,midy;
	//initgraph(&gd,&gm,"...\\bgi");
	midx = getmaxx()/2;
	midy = getmaxy()/2;
	for(t = 0.0;t < 1.0;t += 0.0005)
	{
		xt = pow(1-t,3)*x[0] + 3*t*pow(1-t,2)*x[1] + 3*(1-t)*pow(t,2)*x[2] + pow(t,3)*x[3];
		yt = pow(1-t,3)*y[0] + 3*t*pow(1-t,2)*y[1] + 3*(1-t)*pow(t,2)*y[2] + pow(t,3)*y[3];
		putpixel(xt+midx,midy-yt,WHITE);
	}
	for(i = 0;i < 4;i++)
		putpixel(midx+x[i],midy-y[i],YELLOW);
	//delay(7000);
	//closegraph();
}

int main(void)
{
	int x[4],y[4];
	int i,inp;
	int x1[4] = {0,20,40,60};
	int y1[4] = {0,20,20,0};
	int x2[4] = {0,20,40,60};
	int y2[4] = {0,-20,-20,0};
	int x3[4] = {0,20,20,0};
	int y3[4] = {0,-20,-40,-60};
	int x4[4] = {0,-20,-20,0};
	int y4[4] = {0,-20,-40,-60};
	int x5[4] = {0,-20,-40,-60};
	int y5[4] = {0,-20,-20,0};
	int x6[4] = {0,-20,-40,-60};
	int y6[4] = {0,20,20,0};
	int x7[4] = {0,-20,-20,0};
	int y7[4] = {0,20,40,60};
	int x8[4] = {0,20,20,0};
	int y8[4] = {0,20,40,60};
	printf("\nMenu\n");
	printf("1.Bezier Curve\n2.Pattern\n");
	printf("Enter choice :\n");
	scanf("%d",&inp);
	int gd = DETECT,gm;
	switch(inp)
	{
		case 1:
			printf("Enter coordinates of 4 points :\n");
			for(i = 0;i < 4;i++)
				scanf("%d%d",&x[i],&y[i]);
			bezier(x,y);
			break;

		case 2:
			initgraph(&gd,&gm,"...\\bgi");
			bezier_pattern(x1,y1);
			bezier_pattern(x2,y2);
			bezier_pattern(x3,y3);
			bezier_pattern(x4,y4);
			bezier_pattern(x5,y5);
			bezier_pattern(x6,y6);
			bezier_pattern(x7,y7);
			bezier_pattern(x8,y8);
			delay(7000);
			closegraph();
			break;

		default:
			printf("Invalid choice\n");

	}
}


