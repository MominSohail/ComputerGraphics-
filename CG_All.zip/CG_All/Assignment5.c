

#include<math.h>
#include<graphics.h>
#include <stdio.h> 
#include <stdlib.h>

int xmax,ymax;
typedef struct vertex
{
	int x;
	int y;
}vertex;
void draw_coordinate()
{
	line(0,ymax/2,xmax,ymax/2);
	line(xmax/2,0,xmax/2,ymax);


}
void main()
{
	vertex e[10];
		int i,n,ch,gm,gd=DETECT;
		int tx,ty,sx,sy;
		int theta,c;
		printf("Enter the How Many Vertex you want :- \n");
		scanf("%d",&n);
		for(i=1;i<=n;i++)
		{
			printf("Enter the X & Y coordinates of vertex %d \n",i);
			scanf("%d\n%d",&e[i].x,&e[i].y);
		}
		reflection(e,n);



//getch();
		//delay(10000);
		closegraph();
}
void initialize_graph()
{
	int gd=DETECT,gm;
	detectgraph(&gd,&gm);
			initgraph(&gd,&gm,"");
			xmax=getmaxx();
			ymax=getmaxy();
			draw_coordinate();
}
void draw_poly(vertex e[],int n)
{
	int i;
	int x0=(xmax/2),y0=(ymax/2);
			for(i=1;i<n;i++)
			{
				//setcolor(3);
				line(x0+e[i].x,y0-e[i].y,x0+e[i+1].x,y0-e[i+1].y);
				delay(200);
			}
			line(x0+e[i].x,y0-e[i].y,x0+e[1].x,y0-e[1].y);

}

void reflection(vertex e[],int n)
{
	int ch;
     while(ch<4)
{
	printf("\nMenu\n1.About X-axis\n2.About Y-axis\n3.About Origin \n4.About Abitrary");
        printf("\nEnter Your Choice:");
	scanf("%d",&ch);
	setcolor(BLUE);
	initialize_graph();

	switch(ch)
	{
	case 1:
        about_x(e,n);
		break;
	case 2:
	about_y(e,n);
		break;
	case 3:
		about_origin(e,n);
		break;
  case 4:
          about_arbitrary(e,n);

}
	}
}
void about_x(vertex e[],int n)
{
	draw_poly(e,n);
	int t[2][2]={1,0,0,-1};
	outtextxy(10,10,"Reflection about X-axis !");
	int pdash[2][1];
	int i,j,k,l;
		for(i=1;i<=n;i++)
		{
			int p[2][1]={e[i].x,e[i].y,1};
			  for(j=0;j<2;j++)
			  {
				  for(k=0;k<2;k++)
				  {
					  pdash[j][k]=0;
					  for(l=0;l<2;l++)
					  {
						  pdash[j][k]=pdash[j][k]+(t[j][l]*p[l][k]);
					  }
				  }
			  }
			  e[i].x=pdash[0][0];
			  e[i].y=pdash[1][0];
			  //printf("");

		}
		setcolor(YELLOW);
					  draw_poly(e,n);

   delay(500);
}

void about_y(vertex e[],int n)
{
	draw_poly(e,n);
	int t[2][2]={-1,0,1,0,};
	int pdash[2][1];
	outtextxy(10,10,"Reflection about Y-axis !");
	int i,j,k,l;
		for(i=1;i<=n;i++)
		{
			int p[2][1]={e[i].x,e[i].y,1};
			  for(j=0;j<2;j++)
			  {
				  for(k=0;k<2;k++)
				  {
					  pdash[j][k]=0;
					  for(l=0;l<2;l++)
					  {
						  pdash[j][k]=pdash[j][k]+(t[j][l]*p[l][k]);
					  }
				  }
			  }
			  e[i].x=pdash[0][0];
			  e[i].y=pdash[1][0];
			  //printf("");

		}
		setcolor(YELLOW);
					  draw_poly(e,n);

delay(500);
}

void about_origin(vertex e[],int n)
{
	draw_poly(e,n);
	int t[3][3]={-1,0,0,0,-1,0,0,0,1};
	int pdash[3][1];
	int i,j,k,l;
	outtextxy(10,10,"Reflection about origin !");
		for(i=1;i<=n;i++)
		{
			int p[3][1]={e[i].x,e[i].y,1};
			  for(j=0;j<3;j++)
			  {
				  for(k=0;k<1;k++)
				  {
					  pdash[j][k]=0;
					  for(l=0;l<3;l++)
					  {
						  pdash[j][k]=pdash[j][k]+(t[j][l]*p[l][k]);
					  }
				  }
			  }
			  e[i].x=pdash[0][0];
			  e[i].y=pdash[1][0];
			  //printf("");

		}
		setcolor(YELLOW);
					  draw_poly(e,n);

delay(500);
}


void about_arbitrary(vertex e[],int n)
{
	draw_poly(e,n);
	int t[2][2]={0,1,1,0};
	outtextxy(10,10,"Reflection about Arbitrary !");
	int pdash[2][1];
	int i,j,k,l;
		for(i=1;i<=n;i++)
		{
			int p[2][1]={e[i].x,e[i].y};
			  for(j=0;j<2;j++)
			  {
				  for(k=0;k<2;k++)
				  {
					  pdash[j][k]=0;
					  for(l=0;l<2;l++)
					  {
						  pdash[j][k]=pdash[j][k]+(t[j][l]*p[l][k]);
					  }
				  }
			  }
			  e[i].x=pdash[0][0];
			  e[i].y=pdash[1][0];
			  //printf("");

		}
		setcolor(YELLOW);
					  draw_poly(e,n);

   delay(1000);
}

