
#include<stdio.h>
#include<math.h>
#include<graphics.h>
int maxx,maxy;

void draw_cc()
{
	line(0,maxy/2,maxx,maxy/2);
	line(maxx/2,0,maxx/2,maxy);
}
int main()
{
	int gd=DETECT,gm,x1,y1,rad,ch;


	printf("\nMenu::\n1.Midpoint generation\n2.Bresenham circle Drawing\n3.DDA Cicle drawing algorithm\n4.Exit\n\nEnter your choice");
	scanf("%d",&ch);
	switch(ch)
	{
	case 1:
	printf("\nEnter the coordinates for center of circle X1,Y1\n");
	scanf("%d%d",&x1,&y1);
	printf("\nEnter the radius of circle\n");
	scanf("%d",&rad);
	initgraph(&gd,&gm,"");
		//detectgraph(&gd,&gm);
		maxx=getmaxx();
		maxy=getmaxy();

	draw_cc();
    outtextxy(10,10,"MidPoint's Circle");
	cir_mid(x1,y1,rad);
	break;

	case 2:

	printf("\nEnter the coordinates for center of circle X1,Y1\n");
	scanf("%d%d",&x1,&y1);
	printf("\nEnter the radius of circle\n");
	scanf("%d",&rad);
	initgraph(&gd,&gm,"");
	detectgraph(&gd,&gm);
	maxx=getmaxx();
	maxy=getmaxy();

	draw_cc();
	outtextxy(10,10,"Bresenham's Circle");
	cir_bre(x1,y1,rad);
	break;

	case 3:

	printf("\nEnter the coordinates for center of circle X1,Y1\n");
	scanf("%d%d",&x1,&y1);
	printf("\nEnter the radius of circle\n");
	scanf("%d",&rad);
	initgraph(&gd,&gm,"");
		detectgraph(&gd,&gm);
		maxx=getmaxx();
		maxy=getmaxy();

	draw_cc();
	outtextxy(10,10,"DDA Circle");


	cir_dda(x1,y1,rad);
	break;
	case 4:
		break;
   default:
	printf("\nEnter valid choice");
	break;
}


	getch();
	closegraph();

}

void cir_mid(int x1,int y1,int r)
{
	int x,y,p;
	x1=x1+(getmaxx() / 2);
	y1=(getmaxy() / 2)-y1;
	x=0;
	y=r;
	p=1-r;
	while(x<=y)
	{
		if(p<0)
		{
			x=x+1;
			p=p+(2*x)+1;
		}
		else
		{
			x=x+1;
			y=y-1;
			p+=2*(x-y)+1;
		}
		display(x,y,x1,y1);
	}
}

void display(int x,int y,int x1,int y1)
	{
		delay(50);
		putpixel(x+x1,y+y1,1);
		putpixel(x+x1,y1-y,2);
		putpixel(x1-x,y+y1,3);
		putpixel(x1-x,y1-y,4);
		putpixel(x1+y,y1+x,5);
		putpixel(x1+y,y1-x,6);
		putpixel(x1-y,y1+x,7);
		putpixel(x1-y,y1-x,8);
	}
void cir_bre(int x1,int y1,int r)
{
	int x,y,p;
	x1=x1+(getmaxx() / 2);
	y1=(getmaxy() / 2)-y1;
	x=0;
	y=r;
	p=3-(2*r);
	while(x<=y)
	{
		if(p<0)
		{

			p=p+(4*x)+6;
			x=x+1;
		}
		else
		{
			p+=4*(x-y)+10;
			x=x+1;
			y=y-1;

		}
		display(x,y,x1,y1);
	}
}



void cir_dda(int x,int y,int r)
{
  float x1,x2,y1,y2,eps,sx,sy;
  int val,i;
	x=x+(getmaxx() / 2);
	y=(getmaxy() / 2)-y;

  x1=r;
  y1=0;
  sx=x1;
  sy=y1;
  i=0;

  do{
      val=pow(2,i);
      i++;
      }while(val<r);
  eps = 1/pow(2,i-1);
  do{
      x2 = x1 + y1*eps;
      y2 = y1 - eps*x2;
      putpixel(x+x2,y-y2,3);
     x1=x2;
     y1=y2;

     }while((y1-sy)<eps || (sx-x1)>eps);

}

