#include<math.h>
#include<graphics.h>
#include <stdio.h>
#include <stdlib.h>

int xmax,ymax;
typedef struct vertex
{
	int x;
	int y;
}vertex;
void draw_coordinate()
{
	line(0,ymax/2,xmax,ymax/2);
	line(xmax/2,0,xmax/2,ymax);
}


void initialize_graph();

void draw_poly(vertex e[],int n);

void translate(int tx,int ty,int n,vertex e[]);

void rotation(int theta,int n,vertex e[]);

void scaling(int sx,int sy,int n,vertex e[]);
void main()
{
	vertex e[10];
		int i,n,ch=0;
		int tx,ty,sx,sy;
		int theta,c;
		printf("Enter the How Many Vertex you have of polygon :- \n");
		scanf("%d",&n);
		for(i=1;i<=n;i++)
		{
			printf("Enter the X & Y coordinates of vertex %d \n",i);
			scanf("%d\n%d",&e[i].x,&e[i].y);
		}
           while(ch<4)
             {
		printf("\nMenu\n1.Translation\n2.Rotation\n3.Scaling");
                printf("\nEnter Your choice: ");
		scanf("%d",&ch);
		switch(ch)
		{
		case 1:
			printf("\nEnter translation points (tx & ty)");
			scanf("%d%d",&tx,&ty);
			initialize_graph();
			setcolor(BLUE);
			draw_poly(e,n);
			setcolor(YELLOW);
			translate(tx,ty,n,e);
			draw_poly(e,n);
			break;
                case 2:

							printf("\nEnter angle of rotation");
							scanf("%d",&theta);
							initialize_graph();
							setcolor(BLUE);
							draw_poly(e,n);
							rotation(theta,n,e);
							 setcolor(YELLOW);
							draw_poly(e,n);

							break;

		case 3:
					printf("\nEnter Scaling points (sx & sy)");
					scanf("%d%d",&sx,&sy);
					initialize_graph();
					setcolor(BLUE);
					draw_poly(e,n);
					scaling(sx,sy,n,e);
					setcolor(YELLOW);
					draw_poly(e,n);

					break;
		
		}

              }
//getch();
		//delay(10000);
		closegraph();
}
void initialize_graph()
{
	int gd=DETECT,gm;
	//detectgraph(&gd,&gm);
			initgraph(&gd,&gm,NULL);
			xmax=getmaxx();
			ymax=getmaxy();
			draw_coordinate();
}
void draw_poly(vertex e[],int n)
{
	int i;
	int x0=(xmax/2),y0=(ymax/2);
			for(i=1;i<n;i++)
			{
				//setcolor(3);
				line(x0+e[i].x,y0-e[i].y,x0+e[i+1].x,y0-e[i+1].y);
				delay(200);
			}
			line(x0+e[i].x,y0-e[i].y,x0+e[1].x,y0-e[1].y);

}


void translate(int tx,int ty,int n,vertex e[])
{
	int t[3][3]={1,0,tx,0,1,ty,0,0,1},pdash[3][1];
	int i,j,k,l;
	for(i=1;i<=n;i++)
	{
		int p[3][1]={e[i].x,e[i].y,1};
		  for(j=0;j<3;j++)
		  {
			  for(k=0;k<1;k++)
			  {
				  pdash[j][k]=0;
				  for(l=0;l<3;l++)
				  {
					  pdash[j][k]=pdash[j][k]+(t[j][l]*p[l][k]);
				  }
			  }
		  }
		  e[i].x=pdash[0][0];
		  e[i].y=pdash[1][0];
		  //printf("");
	}


}

void scaling(int sx,int sy,int n,vertex e[])
{

	int t[2][2]={sx,0,0,sy},sdash[2][1];
	int i,j,k,l;
	for(i=1;i<=n;i++)
	{
		int s[2][1]={e[i].x,e[i].y};
		  for(j=0;j<2;j++)
		  {
			  for(k=0;k<2;k++)
			  {
				  sdash[j][k]=0;
				  for(l=0;l<2;l++)
				  {
					  sdash[j][k]=sdash[j][k]+(t[j][l]*s[l][k]);
				  }
			  }
		  }
		  e[i].x=sdash[0][0];
		  e[i].y=sdash[1][0];
	}
                               
}


void rotation(int theta,int n,vertex e[])
{
	float angr=(3.14/180)*theta;
	float t[3][3]={cos(angr),-sin(angr),0,sin(angr),cos(angr),0,0,0,1},rdash[3][1];
	int i,j,k,l;
	for(i=1;i<=n;i++)
	{
		int r[3][1]={e[i].x,e[i].y,1};
		  for(j=0;j<3;j++)
		  {
			  for(k=0;k<1;k++)
			  {
				  rdash[j][k]=0;
				  for(l=0;l<3;l++)
				  {
					  rdash[j][k]=rdash[j][k]+(t[j][l]*r[l][k]);
				  }
			  }
		  }
		  e[i].x=rdash[0][0];
		  e[i].y=rdash[1][0];
	}

                                           
}
