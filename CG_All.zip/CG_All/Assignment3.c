
#include<stdio.h>
#include<graphics.h>
#include<stdlib.h>


typedef struct node
{
	int x,y;
	struct node *next;
}node;


node* push(node *head,int x,int y)
{
	node *nw;
	nw=(struct node*) malloc(sizeof(struct node));
	nw->x=x;
	nw->y=y;
	nw->next=NULL;
	if(head==NULL)
	head=nw;
	else
	{
		head->next=nw;
		head=nw;
	}
	return head;
}


node *pop(node *top)
{
	node *temp;
	temp=top;
	top=top->next;
	free(temp);
	return top;
}

int isEmpty(node *top)
{
	if(top==NULL)
	return 1;
	return 0;
}

void bon(int x,int y,int b,int c)
{
	node *head=NULL;
	node *top;
	head=push(head,x,y);
	top=head;
	while(!isEmpty(top))
	{
		x=top->x;
		y=top->y;
		putpixel(x,y,c);
		if(getpixel(x,y+1)!=b && getpixel(x,y+1)!=c)
		{
			putpixel(x,y+1,c);
			head=push(head,x,y+1);
		}

		if(getpixel(x,y-1)!=b && getpixel(x,y-1)!=c)
		{
			putpixel(x,y-1,c);
			head=push(head,x,y-1);
		}

		if(getpixel(x+1,y)!=b && getpixel(x+1,y)!=c)
		{
			putpixel(x+1,y,c);
			head=push(head,x+1,y);
		}

		if(getpixel(x-1,y)!=b && getpixel(x-1,y)!=c)
		{
			putpixel(x-1,y,c);
			head=push(head,x-1,y);
		}
		top=pop(top);
	}
}

void scanline(int a[10][2],int n)
{
	int i,j,k,dy,dx;
	int x,y,temp;
	int xi[20];
	float slope[20];
	a[n][0]=a[0][0];
	a[n][1]=a[0][1];
	for(i=0;i<n;i++)
	{
		line(a[i][0],a[i][1],a[i+1][0],a[i+1][1]);
	}

	getch();

	for(i=0;i<n;i++)
	{
		dy=a[i+1][1]-a[i][1];
		dx=a[i+1][0]-a[i][0];

		if(dy==0) slope[i]=1.0;
		if(dx==0) slope[i]=0.0;

		if((dy!=0)&&(dx!=0)) /*- calculate inverse slope -*/
		{
			slope[i]=(float) dx/dy;
		}
	}

	for(y=0;y<480;y++)
	{
		k=0;
		for(i=0;i<n;i++)
		{

			if( ((a[i][1]<=y)&&(a[i+1][1]>y))||((a[i][1]>y)&&(a[i+1][1]<=y)))
			{
				xi[k]=(int)(a[i][0]+slope[i]*(y-a[i][1]));
				k++;
			}
		}

		for(j=0;j<k-1;j++) /*- Arrange x-intersections in order -*/
		
		setcolor(3);
		for(i=0;i<k;i+=2)
		{
			line(xi[i],y,xi[i+1]+1,y);
			delay(10);
		}
	}

}

void flood(int x,int y,int b,int c)
{
	node *head=NULL;
	node *top;
	head=push(head,x,y);
	top=head;
	while(!isEmpty(top))
	{
		x=top->x;
		y=top->y;
		putpixel(x,y,c);
		if(getpixel(x,y+1)==b)
		{
			putpixel(x,y+1,c);
			head=push(head,x,y+1);
		}

		if(getpixel(x,y-1)==b )
		{
			putpixel(x,y-1,c);
			head=push(head,x,y-1);
		}
		if(getpixel(x+1,y)==b )
		{
			putpixel(x+1,y,c);
			head=push(head,x+1,y);
		}
		if(getpixel(x-1,y)==b )
		{
			putpixel(x-1,y,c);
			head=push(head,x-1,y);
		}
		top=pop(top);
	}
}



int accept(int a[10][2])
{
	int i,n,j,click;
	printf(" no of edges:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d%d",&a[i][0],&a[i][1]);

		//setcolor(YELLOW);
		//circle(a[i][0],a[i][1],2);
	}
	//setcolor(15);
	return n;
}

void dispb(int a[10][2],int n)
{
	int i;
	for(i=0;i<n-1;i++)
	{
		line(a[i][0],a[i][1],a[i+1][0],a[i+1][1]);
	}
	line(a[n-1][0],a[n-1][1],a[0][0],a[0][1]);
}

void dispf(int a[10][2],int n)
{
	int i;
	for(i=0;i<n-1;i++)
	{
		setcolor(i+1);
		line(a[i][0],a[i][1],a[i+1][0],a[i+1][1]);
	}
	setcolor(i+1 );
	line(a[n-1][0],a[n-1][1],a[0][0],a[0][1]);
}


void bon_r(int x,int y,int b,int c)
{
	int cur;
	cur=getpixel(x,y);
	putpixel(x,y,c);
	if(cur!=b && cur!=c)
	{

		bon_r(x+1,y,b,c);
		bon_r(x-1,y,b,c);
		bon_r(x,y+1,b,c);
		bon_r(x,y-1,b,c);
	}
}

void main()
{
	int gd=DETECT,gm,ch,x,y,c,b,a[10][2],n,click;


	while(1)
	{
		printf("\n1.Flood Fill\n2.Scanline\n3.Exit\nEnter choice: ");
		scanf("%d",&ch);

		switch(ch)
		{
			
			case 1:
			n=accept(a);

			printf("Enter seed point: ");
			scanf("%d%d",&x,&y);
			initgraph(&gd,&gm,NULL);
			dispf(a,n);
			cleardevice();

			dispf(a,n);
			flood(x,y,0,14);


			break;
			case 2:n=accept(a);
			initgraph(&gd,&gm,NULL);
			dispb(a,n);


			scanline(a,n);
			break;
			default: exit(0);
		}
	}
}
