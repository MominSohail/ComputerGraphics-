
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>


void DDA_Line(float,float,float,float);


void Bresenham_Line(float,float,float,float);


void Thick_Line(float,float,float,float,float);


void Dashed_Line(float,float,float,float);


void Dotted_Line(float,float,float,float);



int main()
{
	int gd = DETECT,gm,ch,xmax=640,ymax=480,xmid,ymid;
	float x1,y1,x2,y2,r,w;
	char ans=' ';

	xmid=xmax/2;
	ymid=ymax/2;

         printf("\nEnter Co-Ordinate of Line :");    
         printf("\nEnter the value of x1:");
         scanf("%f",&x1);

				printf("\nEnter the value of y1:");
				scanf("%f",&y1);

				printf("\nEnter the value of x2:");
				scanf("%f",&x2);


				printf("\nEnter the value of y2:");
				scanf("%f",&y2);
	do
	{

		printf("\nHow You Want to Draw A Line :");
		printf("\n1.Line Drawing Using DDA Algorithm.");
		printf("\n2.Line drawing Using BRESENHAM'S algorithm.");
		printf("\n3.Draw Thick Line.");
		printf("\n4.Draw Dot_Dot Line.");
		printf("\n5.Draw Dash_Dash Line.");
		printf("\n6.Draw Simple Line.");
		printf("\n7.EXIT.");

		printf("\nEnter your choice:");
		scanf("%d",&ch);

		switch(ch)
		{
			case 1:
				initgraph(&gd,&gm,"");
				line(0,ymid,xmax,ymid);
				line(xmid,0,xmid,ymax);
				outtextxy(xmid+5,ymid+8,"O(0,0)");
                                 
				DDA_Line(x1,y1,x2,y2);
				getch();

				break;

			case 2:

				initgraph(&gd,&gm,"");
				cleardevice();
                                setcolor(9);
				line(0,ymid,xmax,ymid);
				line(xmid,0,xmid,ymax);
				outtextxy(xmid+5,ymid+8,"O(0,0)");

				Bresenham_Line(x1,y1,x2,y2);
				getch();
				break;
  
			case 3:
                                printf("\nEnter the thickness:");
				scanf("%f",&w);
				initgraph(&gd,&gm,"");
				cleardevice();

				setcolor(9);
				line(0,ymid,xmax,ymid);
				line(xmid,0,xmid,ymax);
				outtextxy(xmid+5,ymid+8,"O(0,0)");

				Thick_Line(x1,y1,x2,y2,w);
				getch();
				break;

			case 4:
				initgraph(&gd,&gm,"");
				cleardevice();

				setcolor(9);
				line(0,ymid,xmax,ymid);
				line(xmid,0,xmid,ymax);
				outtextxy(xmid+5,ymid+8,"O(0,0)");

				Dotted_Line(x1,y1,x2,y2);
				getch();
				break;

			case 5:
                                initgraph(&gd,&gm,"");
				cleardevice();

				setcolor(9);
				line(0,ymid,xmax,ymid);
				line(xmid,0,xmid,ymax);
				outtextxy(xmid+5,ymid+8,"O(0,0)");

				Dashed_Line(x1,y1,x2,y2);
				getch();
				break;

			case 6:
				initgraph(&gd,&gm,"");
				cleardevice();

				setcolor(9);
				line(0,ymid,xmax,ymid);
				line(xmid,0,xmid,ymax);
				outtextxy(xmid+5,ymid+8,"O(0,0)");

				normal(x1,y1,x2,y2);
				getch();

				break;

			case 7:
				exit(0);

				break;

			default:
				printf("\nEnter correct choice!!!");

				getch();
		}


		cleardevice();

		printf("\nDo you wish to continue?");
		scanf("%c",&ans);
	}while(ans=='y'||ans=='Y');


	closegraph();
	return 0;
}


//Function Definitions 
void DDA_Line(float x1,float y1,float x2,float y2)
{
	int Dx,Dy,steps;
	float xin,yin,x,y;

	Dx=x2-x1;
	Dy=y2-y1;
	if(abs(Dx)>=abs(Dy))
		steps=abs(Dx);
	else
	    steps=abs(Dy);

	
	xin=((float)Dx)/steps;
	yin=((float)Dy)/steps;
	putpixel((x1+320),(240-y1),YELLOW);
	x=x1;
	y=y1;
       int i=1;
	while(i<=steps)
	{
		x+=xin;
		y+=yin;
		putpixel((round(x)+320),(240-round(y)),RED);
              i++;
	}
	getch();
	closegraph();

}

void Bresenham_Line(float x1,float y1,float x2,float y2)
{
      int dx, dy, G, E;
      float x1, x2, y1, y2, x, y;
      
      dx = abs(x1 - x2);
      dy = abs(y1 - y2);
      G = 2 * dy - dx;
      if(x1 > x2)
      {
            x = x2;
            y = y2;
            E = x1;
      }
      else
      {
            x = x1;
            y = y1;
            E = x2;
      }
      putpixel(x, y, 10);
      while(x < E)
      {
            x = x + 1;
            if( < 0)
            {
                  G = G + 2 * dy;
            }
            else
            {
                  y = y + 1;
                  G = G + 2 * (dy - dx);
            }
            putpixel(x, y, 10);
      }
      getch();
      
}

}



void normal(float x1,float y1,float x2,float y2)
{
	int i=0;
	float e,x,y,dx,dy;

	dx=abs(x2-x1);
	dy=abs(y2-y1);

	x=x1;
	y=y1;
	i=1;
	e=2*dy-dx;

	do
	{
		putpixel(320+x,240-y,12);
		while(e>=0)
		{
			y=y+1;
			e=e-2*dx;
		}

		x=x+1;
		e=e+2*dy;
		i=i+1;
	}while(i<=dx);

}

void Dotted_Line(float x1,float y1,float x2,float y2)
{
	int i=0;
	float e,x,y,dx,dy;

	dx=abs(x2-x1);
	dy=abs(y2-y1);

	x=x1;
	y=y1;
	i=1;
	e=2*dy-dx;

	do
	{
		if(i%4==2)
		{
			putpixel(320+x,240-y,15);
		}

		while(e>=0)
		{
			y=y+1;
			e=e-2*dx;
		}

		x=x+1;
		e=e+2*dy;
		i=i+1;
	}while(i<=dx);

}

void Dashed_Line(float x1,float y1,float x2,float y2)
{
	int i=0;
	float e,x,y,dx,dy;

	dx=abs(x2-x1);
	dy=abs(y2-y1);

	x=x1;
	y=y1;
	i=1;
	e=2*dy-dx;

	do
	{
		if(i%16<=8)
		{
			putpixel(320+x,240-y,15);
		}

		while(e>=0)
		{
			y=y+1;
			e=e-2*dx;
		}

		x=x+1;
		e=e+2*dy;
		i=i+1;
	}while(i<=dx);

}

void Thick_Line(float x1,float y1,float x2,float y2,float w)
{
	int i=0;
	float x,y;

	line(320+x1,240-y1,320+x2,240-y2);

	if((y2-y1)/(x2-x1)<1)
	{
		y=(w-1)*sqrt(pow((x2-x1),2)+pow((y2-y1),2))/(2*fabs(x2-x1));

		for(i=0;i<y;i++)
		{
			line(320+x1,240-(y1-i),320+x2,240-(y2-i));
			line(320+x1,240-(y1+i),320+x2,240-(y2+i));
		}
	}
	else
	{
		x=(w-1)*sqrt(pow((x2-x1),2)+pow((y2-y1),2))/(2*fabs(y2-y1));

		for(i=0;i<x;i++)
		{
			line(320+(x1-i),240-y1,320+(x2-i),240-y2);
			line(320+(x1+i),240-y1,320+(x2+i),240-y2);
		}
	}

}



